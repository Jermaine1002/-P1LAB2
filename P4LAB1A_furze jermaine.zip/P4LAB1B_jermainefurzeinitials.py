# P4LAB1B_jermainefurze.py
import turtle

# Set up turtle
t = turtle.Turtle()
t.pensize(5)  # Choose pen size
t.pencolor("blue")  # Choose your favorite color

# --- Draw the letter J ---
t.penup()
t.goto(-100, 50)  # Starting position for J
t.setheading(0)
t.pendown()

t.forward(100)      # Top horizontal line
t.backward(50)     # Go back to middle
t.right(270)
t.forward(-100)      # Vertical part
t.circle(10,-180)  # Bottom curve of J

# --- Move to F ---
t.penup()
t.goto(50, 50)     # Starting position for F
t.setheading(270)
t.pendown()

t.forward(100)     # Vertical line of F
t.penup()
t.goto(50, 50)
t.setheading(0)
t.pendown()
t.forward(40)      # Top bar of F

t.penup()
t.goto(50, 0)      # Middle bar of F
t.setheading(0)
t.pendown()
t.forward(30)

# Finish
t.hideturtle()
turtle.done()
