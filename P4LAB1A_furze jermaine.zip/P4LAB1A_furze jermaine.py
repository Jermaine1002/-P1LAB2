# P4LAB1A_furzejermaine.py
import turtle

# Create turtle object square and triangle
t = turtle.Turtle()

# Draw square using a for loop
t.pencolor("blue")
for i in range(4):
    t.forward(90)
    t.left(90)

# Draw triangle using a for loop
t.pencolor("green")
for i in range(4):
    t.forward(90)
    t.left(120)

# Finish
turtle.done()
